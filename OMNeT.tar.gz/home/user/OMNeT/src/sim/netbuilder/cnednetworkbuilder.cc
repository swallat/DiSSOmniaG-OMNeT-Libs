//==========================================================================
//   CNEDNETWORKBUILDER.CC
//
//                     OMNeT++/OMNEST
//            Discrete System Simulation in C++
//
//==========================================================================

/*--------------------------------------------------------------*
  Copyright (C) 2002-2008 Andras Varga
  Copyright (C) 2006-2008 OpenSim Ltd.

  This file is distributed WITHOUT ANY WARRANTY. See the file
  `terms' for details on this and other legal matters.
*--------------------------------------------------------------*/


#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <algorithm>

#include "cmodule.h"
#include "cgate.h"
#include "cchannel.h"
#include "cdataratechannel.h"
#include "ccomponenttype.h"
#include "clongparimpl.h"
#include "cboolparimpl.h"
#include "cstringparimpl.h"
#include "cdisplaystring.h"
#include "cconfiguration.h"
#include "cconfigoption.h"
#include "cenvir.h"

#include "nedelements.h"
#include "nederror.h"

#include "nedparser.h"
#include "nedxmlparser.h"
#include "neddtdvalidator.h"
#include "nedsyntaxvalidator.h"
#include "nedutil.h"
#include "xmlgenerator.h"  // for debugging

#include "cnednetworkbuilder.h"
#include "cnedloader.h"
#include "cexpressionbuilder.h"
#include "nedsupport.h"
#include "commonutil.h"  // TRACE()
#include "stringutil.h"
#include "patternmatcher.h"

USING_NAMESPACE

Register_PerRunConfigOption(CFGID_MAX_MODULE_NESTING, "max-module-nesting", CFG_INT, "50", "The maximum allowed depth of submodule nesting. This is used to catch accidental infinite recursions in NED.");
Register_PerObjectConfigOption(CFGID_TYPE_NAME, "type-name", CFG_STRING, NULL, "Specifies type for submodules and channels declared with 'like <>'.");


#if 0
// for debugging
static void dump(NEDElement *node)
{
    generateXML(std::cout, node, false);
    std::cout.flush();
}
#endif

// utility function for exception handling: adds NED file+line to the exception text
static void updateOrRethrowException(std::exception& e, NEDElement *context)
{
    const char *loc = context ? context->getSourceLocation() : NULL;
    if (!opp_isempty(loc))
    {
        std::string msg = std::string(e.what()) + ", at " + loc;
        cException *ce = dynamic_cast<cException *>(&e);
        if (ce)
           ce->setMessage(msg.c_str());
        else
           throw cRuntimeError("%s", msg.c_str()); // cannot set msg on existing exception object, throw new one
    }
}

void cNEDNetworkBuilder::addParametersAndGatesTo(cComponent *component, cNEDDeclaration *decl)
{
    cContextSwitcher __ctx(component); // params need to be evaluated in the module's context FIXME needed???
    doAddParametersAndGatesTo(component, decl);

    // assign submodule/connection parameters using parent module NED declaration as well
    cModule *parentModule = component->getParentModule();
    if (parentModule)
    {
        const char *parentNedTypeName = parentModule->getNedTypeName();
        cNEDDeclaration *parentDecl = cNEDLoader::getInstance()->getDecl(parentNedTypeName);
        if (parentDecl)  // i.e. parent was created via NED-based componentType
        {
            NEDElement *subcomponentNode = component->isModule() ?
                (NEDElement *)parentDecl->getSubmoduleElement(component->getName()) :
                (NEDElement *)parentDecl->getConnectionElement(((cChannel*)component)->getConnectionId());
            if (subcomponentNode)
                assignSubcomponentParams(component, subcomponentNode);
        }
    }

    assignParametersFromPatterns(component);
}

void cNEDNetworkBuilder::doAddParametersAndGatesTo(cComponent *component, cNEDDeclaration *decl)
{
    //TRACE("addParametersAndGatesTo(%s), decl=%s", component->getFullPath().c_str(), decl->getName()); //XXX

    //TODO for performance: component->reallocParamv(decl->getParameterDeclarations().size());

    // recursively add and assign super types' parameters
    if (decl->numExtendsNames() > 0)
    {
        const char *superName = decl->extendsName(0);
        cNEDDeclaration *superDecl = cNEDLoader::getInstance()->getDecl(superName);
        doAddParametersAndGatesTo(component, superDecl);
    }

    // add this decl parameters / assignments
    ParametersElement *paramsNode = decl->getParametersElement();
    if (paramsNode)
    {
        currentDecl = decl; // switch "context"
        doParams(component, paramsNode, false);
    }

    // add this decl's gates (if there are any)
    GatesElement *gatesNode = decl->getGatesElement();
    if (gatesNode)
    {
        currentDecl = decl; // switch "context"
        doGates((cModule *)component, gatesNode, false);
    }
}

cPar::Type cNEDNetworkBuilder::translateParamType(int t)
{
    return t==NED_PARTYPE_DOUBLE ? cPar::DOUBLE :
           t==NED_PARTYPE_INT ? cPar::LONG :
           t==NED_PARTYPE_STRING ? cPar::STRING :
           t==NED_PARTYPE_BOOL ? cPar::BOOL :
           t==NED_PARTYPE_XML ? cPar::XML :
           (cPar::Type)-1;
}

cGate::Type cNEDNetworkBuilder::translateGateType(int t)
{
    return t==NED_GATETYPE_INPUT ? cGate::INPUT :
           t==NED_GATETYPE_OUTPUT ? cGate::OUTPUT :
           t==NED_GATETYPE_INOUT ? cGate::INOUT :
           (cGate::Type)-1;
}

void cNEDNetworkBuilder::doParams(cComponent *component, ParametersElement *paramsNode, bool isSubcomponent)
{
    ASSERT(paramsNode!=NULL);
    for (ParamElement *paramNode=paramsNode->getFirstParamChild(); paramNode; paramNode=paramNode->getNextParamSibling())
        if (!paramNode->getIsPattern())
            doParam(component, paramNode, isSubcomponent);
}

void cNEDNetworkBuilder::doParam(cComponent *component, ParamElement *paramNode, bool isSubcomponent)
{
    ASSERT(!paramNode->getIsPattern()); // we only deal with non-pattern assignments

    try {
        const char *paramName = paramNode->getName();

        // isSubComponent==false: we are called from cModuleType::addParametersAndGatesTo();
        // isSubComponent==true: we are called from assignSubcomponentParams().
        // if type==NONE, this is an inherited parameter (must have been added already)
        bool isNewParam = !isSubcomponent && paramNode->getType()!=NED_PARTYPE_NONE;

        // try to find an impl object with this value; we'll reuse it to optimize memory consumption
        cParImpl *impl = currentDecl->getSharedParImplFor(paramNode);
        if (impl)
        {
            //printf("   +++ reusing param impl for %s\n", paramName);

            // we've already been at this point in the NED files sometime,
            // so we can reuse what we produced then
            ASSERT(impl->isName(paramName));
            if (isNewParam)
                component->addPar(impl);
            else {
                cPar& par = component->par(paramName); // must exist already
                if (par.isSet())
                    throw cRuntimeError(component, "Cannot overwrite non-default value of parameter `%s'", paramName);
                par.setImpl(impl);
            }
            return;
        }

        ASSERT(impl==NULL);
        if (isNewParam) {
            //printf("   +++ adding param %s\n", paramName);
            impl = cParImpl::createWithType(translateParamType(paramNode->getType()));
            impl->setName(paramName);
            impl->setIsShared(false);
            impl->setIsVolatile(paramNode->getIsVolatile());

            component->addPar(impl);

            cProperties *paramProps = component->par(paramName).getProperties();
            cProperty *unitProp = paramProps->get("unit");
            const char *declUnit = unitProp ? unitProp->getValue(cProperty::DEFAULTKEY) : NULL;
            impl->setUnit(declUnit);
        }
        else {
            cPar& par = component->par(paramName); // must exist already
            if (par.isSet())
                throw cRuntimeError(component, "Cannot overwrite non-default value of parameter `%s'", paramName);
            impl = par.copyIfShared();
        }

        ASSERT(!impl->isSet());  // we do not overwrite assigned values

        // put new value into impl
        ExpressionElement *exprNode = paramNode->getFirstExpressionChild();
        if (exprNode)
        {
            //printf("   +++ assigning param %s\n", paramName);
            ASSERT(impl==component->par(paramName).impl() && !impl->isShared());
            cDynamicExpression *dynamicExpr = cExpressionBuilder().process(exprNode, isSubcomponent);
            cExpressionBuilder::setExpression(impl, dynamicExpr);
            impl->setIsSet(!paramNode->getIsDefault());
        }
        else if (paramNode->getIsDefault())
        {
            // Note: this branch ("=default" in NED files) is currently not supported,
            // because it would be complicated to implement in the Inifile Editor.

            //printf("   +++ setting param %s to default\n", paramName);
            if (!impl->containsValue())
                throw cRuntimeError(component, "Cannot apply default value to parameter `%s': it has no default value", paramName);
            impl->setIsSet(true);
        }
        impl->setIsShared(true);
        currentDecl->putSharedParImplFor(paramNode, impl);

    }
    catch (std::exception& e) {
        updateOrRethrowException(e, paramNode); throw;
    }
}

void cNEDNetworkBuilder::doGates(cModule *module, GatesElement *gatesNode, bool isSubcomponent)
{
    ASSERT(gatesNode!=NULL);
    for (NEDElement *child=gatesNode->getFirstChildWithTag(NED_GATE); child; child=child->getNextSiblingWithTag(NED_GATE))
        doGate(module, (GateElement *)child, isSubcomponent);
}

void cNEDNetworkBuilder::doGate(cModule *module, GateElement *gateNode, bool isSubcomponent)
{
    try {
        // add gate if it's declared here
        if (!isSubcomponent && gateNode->getType()!=NED_GATETYPE_NONE)
            module->addGate(gateNode->getName(), translateGateType(gateNode->getType()), gateNode->getIsVector());
    }
    catch (std::exception& e) {
        updateOrRethrowException(e, gateNode); throw;
    }
}

void cNEDNetworkBuilder::assignParametersFromPatterns(cComponent *component)
{
    // go up the parent chain, and apply the parameter pattern assignments
    // to matching, still-unset parameters
    //XXX printf("TRYING TO ASSIGN PARAMS OF %s USING PATTERNS\n", component->getFullPath().c_str());

    std::string prefix;

    for (cComponent *child = component; true; child = child->getParentModule())
    {
        cModule *parent = child->getParentModule();
        if (!parent)
            break;

        //XXX printf(" CHECKING PATTERNS ON: %s\n", parent->getFullPath().c_str());

        // find NED declaration. Note that decl may be NULL (if parent was not defined via NED)
        const char *nedTypeName = parent->getNedTypeName();
        cNEDDeclaration *decl = cNEDLoader::getInstance()->getDecl(nedTypeName);

        // first, check patterns in the "submodules:" section
        if (decl && !prefix.empty())
        {
            const std::vector<PatternData>& submodPatterns = decl->getSubmoduleParamPatterns(child->getName());
            if (!submodPatterns.empty())
                doAssignParametersFromPatterns(component, prefix, submodPatterns);
        }

        // for checking the patterns on the compound module, prefix with submodule name
        if (child->isModule())
            prefix = std::string(child->getFullName()) + "." + prefix;
        else {
            // channel: its path includes the connection source gate's name
            cObject *srcGate = child->getOwner();
            ASSERT(srcGate == ((cChannel*)child)->getSourceGate());
            prefix = std::string(srcGate->getFullName()) + "."  + child->getFullName() + "." + prefix; // prepend with "<srcgate>.channel."
            if (srcGate->getOwner() != parent)
                prefix = std::string(srcGate->getOwner()->getFullName()) + "."  + prefix; // also prepend with "<submod>."
        }

        // check patterns on the compound module itself
        if (decl)
        {
            const std::vector<PatternData>& patterns = decl->getParamPatterns();
            if (!patterns.empty())
                doAssignParametersFromPatterns(component, prefix, patterns);
        }
    }
}

void cNEDNetworkBuilder::doAssignParametersFromPatterns(cComponent *component, const std::string& prefix, const std::vector<PatternData>& patterns)
{
    int numPatterns = patterns.size();
    //XXX for (int i=0; i<numPatterns; i++)
    //XXX     printf("    pattern %d: %s  (from \"%s=\" at %s)\n", i, patterns[i].matcher->debugStr().c_str(), patterns[i].patternNode->getName(), patterns[i].patternNode->getSourceLocation());

    int numParams = component->getNumParams();
    for (int i=0; i<numParams; i++) {
        cPar& par = component->par(i);
        if (!par.isSet()) {
            // first match
            std::string paramPath = prefix + par.getFullName();
            //XXX printf("  checking param %s as \"%s\"\n", par.getFullPath().c_str(), paramPath.c_str());
            for (int j=0; j<numPatterns; j++) {
                if (patterns[j].matcher->matches(paramPath.c_str())) {
                    //XXX printf("   ^ %s matches it, assigning!\n", patterns[j].matcher->debugStr().c_str());
                    doAssignParameterFromPattern(par, patterns[j].patternNode);
                    if (par.isSet())
                        break;
                }
            }
        }
    }
}

void cNEDNetworkBuilder::doAssignParameterFromPattern(cPar& par, ParamElement *patternNode)
{
    // note: this code should look similar to relevant part of doParam()
    try {
        ASSERT(patternNode->getIsPattern());
        cParImpl *impl = par.copyIfShared();
        ExpressionElement *exprNode = patternNode->getFirstExpressionChild();
        if (exprNode)
        {
            //printf("   +++ assigning param %s\n", paramName);
            ASSERT(impl==par.impl() && !impl->isShared());
            bool isSubcomponent = false; //FIXME is this OK?
            cDynamicExpression *dynamicExpr = cExpressionBuilder().process(exprNode, isSubcomponent);
            cExpressionBuilder::setExpression(impl, dynamicExpr);
            impl->setIsSet(!patternNode->getIsDefault());
        }
        else if (patternNode->getIsDefault())
        {
            // Note: this branch ("=default" in NED files) is currently not supported,
            // because it would be complicated to implement in the Inifile Editor.

            //FIXME is this so??? ^^^

            //printf("   +++ setting param %s to default\n", patternNode);
            if (!impl->containsValue())
                throw cRuntimeError(par.getOwner(), "Cannot apply default value to parameter `%s': it has no default value", par.getName());
            impl->setIsSet(true);
        }
        //XXX impl->setIsShared(true);
        //XXX currentDecl->putSharedParImplFor(patternNode, impl);
    }
    catch (std::exception& e) {
        updateOrRethrowException(e, patternNode); throw;
    }
}

cModule *cNEDNetworkBuilder::_submodule(cModule *, const char *submodname, int idx)
{
    SubmodMap::iterator i = submodMap.find(std::string(submodname));
    if (i==submodMap.end())
        return NULL;

    ModulePtrVector& v = i->second;
    if (idx<0)
        return (v.size()!=1 || v[0]->isVector()) ? NULL : v[0];
    else
        return ((unsigned)idx>=v.size()) ? NULL : v[idx];
}

void cNEDNetworkBuilder::doGateSizes(cModule *module, GatesElement *gatesNode, bool isSubcomponent)
{
    ASSERT(gatesNode!=NULL);
    for (NEDElement *child=gatesNode->getFirstChildWithTag(NED_GATE); child; child=child->getNextSiblingWithTag(NED_GATE))
        doGateSize(module, (GateElement *)child, isSubcomponent);
}

void cNEDNetworkBuilder::doGateSize(cModule *module, GateElement *gateNode, bool isSubcomponent)
{
    try {
        if (gateNode->getIsVector()) {
            // if there's a gatesize expression given, apply it
            ExpressionElement *exprNode = gateNode->getFirstExpressionChild();
            if (exprNode)
            {
                // ExpressionElement first needs to be compiled into a cParImpl
                // for evaluation; these cParImpl's are cached
                cParImpl *value = currentDecl->getSharedParImplFor(exprNode);
                if (!value)
                {
                    // not yet seen, compile and cache it
                    cDynamicExpression *dynamicExpr = cExpressionBuilder().process(exprNode, isSubcomponent);
                    value = new cLongParImpl();
                    value->setName("gatesize-expression");
                    cExpressionBuilder::setExpression(value, dynamicExpr);
                    currentDecl->putSharedParImplFor(exprNode, value);
                }

                // evaluate the expresssion, and set the gate vector size
                int gatesize = value->longValue(module);
                module->setGateSize(gateNode->getName(), gatesize);
            }
        }
    }
    catch (std::exception& e) {
        updateOrRethrowException(e, gateNode); throw;
    }
}

void cNEDNetworkBuilder::setupGateVectors(cModule *module, cNEDDeclaration *decl)
{
    //TRACE("setupGateVectors(%s), decl=%s", module->getFullPath().c_str(), decl->getName()); //XXX

    // recursively add super types' gates
    if (decl->numExtendsNames() > 0)
    {
        const char *superName = decl->extendsName(0);
        cNEDDeclaration *superDecl = cNEDLoader::getInstance()->getDecl(superName);
        setupGateVectors(module, superDecl);
    }

    // add this decl's gatesizes
    GatesElement *gatesNode = decl->getGatesElement();
    if (gatesNode)
    {
        currentDecl = decl; // switch "context"
        doGateSizes(module, gatesNode, false);
    }
}

void cNEDNetworkBuilder::buildInside(cModule *modp, cNEDDeclaration *decl)
{
    //TRACE("buildinside(%s), decl=%s", modp->getFullPath().c_str(), decl->getName());  //XXX

    if (modp->getId() % 50 == 0)
    {
        // half-hearted attempt to catch "recursive compound module" bug (where
        // a compound module contains itself, directly or via other compound modules)
        int limit = ev.getConfig()->getAsInt(CFGID_MAX_MODULE_NESTING);
        if (limit>0)
        {
            int depth = 0;
            for (cModule *p=modp; p; p=p->getParentModule())
                depth++;
            if (depth > limit)
                throw cRuntimeError(modp, "Submodule nesting too deep (%d) (potential infinite recursion?)", depth);
        }
    }

    // add submodules and connections. Submodules and connections are inherited:
    // we need to start start with the the base classes, and do this compound
    // module last.
    submodMap.clear();
    buildRecursively(modp, decl);

    // check if there are unconnected gates left -- unless unconnected gates were already permitted in the super type
    ConnectionsElement *conns = decl->getConnectionsElement();
    if ((!conns || !conns->getAllowUnconnected()) && !superTypeAllowsUnconnected(decl))
        modp->checkInternalConnections();

    // recursively build the submodules too (top-down)
    currentDecl = decl;
    for (cModule::SubmoduleIterator submod(modp); !submod.end(); submod++)
    {
        cModule *m = submod();
        m->buildInside();
    }
}

void cNEDNetworkBuilder::buildRecursively(cModule *modp, cNEDDeclaration *decl)
{
    // recursively add super types' submodules and connections
    if (decl->numExtendsNames() > 0)
    {
        const char *superName = decl->extendsName(0);
        cNEDDeclaration *superDecl = cNEDLoader::getInstance()->getDecl(superName);
        buildRecursively(modp, superDecl);
    }

    currentDecl = decl; // switch "context"
    addSubmodulesAndConnections(modp);
}

void cNEDNetworkBuilder::addSubmodulesAndConnections(cModule *modp)
{
    //TRACE("addSubmodulesAndConnections(%s), decl=%s", modp->getFullPath().c_str(), currentDecl->getName()); //XXX
    //dump(currentDecl->getTree()); XXX

    SubmodulesElement *submods = currentDecl->getSubmodulesElement();
    if (submods)
        for (SubmoduleElement *submod=submods->getFirstSubmoduleChild(); submod; submod=submod->getNextSubmoduleSibling())
            addSubmodule(modp, submod);

    // loop through connections and add them
    ConnectionsElement *conns = currentDecl->getConnectionsElement();
    if (conns)
        for (NEDElement *child=conns->getFirstChild(); child; child=child->getNextSibling())
            if (child->getTagCode()==NED_CONNECTION || child->getTagCode()==NED_CONNECTION_GROUP)
                addConnectionOrConnectionGroup(modp, child);
}

bool cNEDNetworkBuilder::superTypeAllowsUnconnected(cNEDDeclaration *decl) const
{
    // follow through the inheritance chain, and return true if we find an "allowunconnected" anywhere
    while (decl->numExtendsNames() > 0)
    {
        const char *superName = decl->extendsName(0);
        decl = cNEDLoader::getInstance()->getDecl(superName);
        ASSERT(decl); // all super classes must be loaded before we start building
        ConnectionsElement *conns = decl->getConnectionsElement();
        if (conns && conns->getAllowUnconnected())
            return true;
    }
    return false;
}

std::string cNEDNetworkBuilder::resolveComponentType(const NEDLookupContext& context, const char *nedtypename)
{
    // Resolve a NED module/channel type name, for a submodule or channel
    // instance. Lookup is based on component names registered in the simkernel,
    // NOT on the NED files loaded. This allows the user to instantiate
    // cModuleTypes/cChannelTypes which are not declared in NED.
    ComponentTypeNames qnames;
    return cNEDLoader::getInstance()->resolveNedType(context, nedtypename, &qnames);
}

cModuleType *cNEDNetworkBuilder::findAndCheckModuleType(const char *modTypeName, cModule *modp, const char *submodname)
{
    //FIXME cache the result to speed up further lookups
    NEDLookupContext context(currentDecl->getTree(), currentDecl->getFullName());
    std::string qname = resolveComponentType(context, modTypeName);
    if (qname.empty())
        throw cRuntimeError(modp, "Submodule %s: cannot resolve module type `%s' (not in the loaded NED files?)",
                            submodname, modTypeName);
    cComponentType *componenttype = cComponentType::find(qname.c_str());
    if (!dynamic_cast<cModuleType *>(componenttype))
        throw cRuntimeError(modp, "Submodule %s: `%s' is not a module type",
                            submodname, qname.c_str());
    return (cModuleType *)componenttype;
}

cModuleType *cNEDNetworkBuilder::findAndCheckModuleTypeLike(const char *modTypeName, const char *likeType, cModule *modp, const char *submodname)
{
    //FIXME cache the result to speed up further lookups

    // resolve the interface
    NEDLookupContext context(currentDecl->getTree(), currentDecl->getFullName());
    std::string interfaceqname = cNEDLoader::getInstance()->resolveNedType(context, likeType);
    cNEDDeclaration *interfacedecl = interfaceqname.empty() ? NULL : (cNEDDeclaration *)cNEDLoader::getInstance()->lookup(interfaceqname.c_str());
    if (!interfacedecl)
        throw cRuntimeError(modp, "Submodule %s: cannot resolve module interface `%s'",
                            submodname, likeType);
    if (interfacedecl->getTree()->getTagCode()!=NED_MODULE_INTERFACE)
        throw cRuntimeError(modp, "Submodule %s: `%s' is not a module interface",
                            submodname, interfaceqname.c_str());

    // search for module type that implements the interface
    std::vector<std::string> candidates = findTypeWithInterface(modTypeName, interfaceqname.c_str());
    if (candidates.empty())
        throw cRuntimeError(modp, "Submodule %s: no module type named `%s' found that implements module interface %s (not in the loaded NED files?)",
                            submodname, modTypeName, interfaceqname.c_str());
    if (candidates.size() > 1)
        throw cRuntimeError(modp, "Submodule %s: more than one module types named `%s' found that implement module interface %s (use fully qualified name to disambiguate)",
                            submodname, modTypeName, interfaceqname.c_str());

    cComponentType *componenttype = cComponentType::find(candidates[0].c_str());
    if (!dynamic_cast<cModuleType *>(componenttype))
        throw cRuntimeError(modp, "Submodule %s: `%s' is not a module type",
                            submodname, candidates[0].c_str());
    return (cModuleType *)componenttype;
}

std::vector<std::string> cNEDNetworkBuilder::findTypeWithInterface(const char *nedtypename, const char *interfaceqname)
{
    std::vector<std::string> candidates;

    // try to interpret it as a fully qualified name
    ComponentTypeNames qnames;
    if (qnames.contains(nedtypename)) {
        cNEDDeclaration *decl = cNEDLoader::getInstance()->getDecl(nedtypename);
        ASSERT(decl);
        if (decl->supportsInterface(interfaceqname)) {
            candidates.push_back(nedtypename);
            return candidates;
        }
    }

    if (!strchr(nedtypename, '.'))
    {
        // no dot: name is an unqualified name (simple name). See how many NED types
        // implement the given interface; there should be exactly one
        std::string dot_nedtypename = std::string(".")+nedtypename;
        for (int i=0; i<qnames.size(); i++) {
            const char *qname = qnames.get(i);
            if (opp_stringendswith(qname, dot_nedtypename.c_str()) || strcmp(qname, nedtypename)==0) {
                cNEDDeclaration *decl = cNEDLoader::getInstance()->getDecl(qname);
                ASSERT(decl);
                if (decl->supportsInterface(interfaceqname))
                    candidates.push_back(qname);
            }
        }
    }
    return candidates;
}

std::string cNEDNetworkBuilder::getSubmoduleTypeName(cModule *modp, SubmoduleElement *submod, int index)
{
    const char *submodname = submod->getName();
    std::string submodtypename;
    if (opp_isempty(submod->getLikeType())) {
        submodtypename = submod->getType();
    }
    else
    {
        // type may be given either in ExpressionElement child or "like-param" attribute
        if (!opp_isempty(submod->getLikeParam())) {
            submodtypename = modp->par(submod->getLikeParam()).stringValue();
        }
        else {
            ExpressionElement *likeParamExpr = findExpression(submod, "like-param");
            if (likeParamExpr)
                submodtypename = evaluateAsString(likeParamExpr, modp, false);
            else {
                std::string key = modp->getFullPath() + "." + submodname;
                if (index != -1)
                    key = opp_stringf("%s[%d]", key.c_str(), index);
                submodtypename = ev.getConfig()->getAsString(key.c_str(), CFGID_TYPE_NAME);
                if (submodtypename.empty())
                    throw cRuntimeError(modp, "Unable to determine type name for submodule %s, missing entry %s.%s", submodname, key.c_str(), CFGID_TYPE_NAME->getName());
            }
        }
    }

    return submodtypename;
}

void cNEDNetworkBuilder::addSubmodule(cModule *modp, SubmoduleElement *submod)
{
    // if there is a @dynamic or @dynamic(true), do not instantiate the submodule
    ParametersElement *paramsNode = submod->getFirstParametersChild();
    if (paramsNode)
        for (PropertyElement *prop = paramsNode->getFirstPropertyChild(); prop!=NULL; prop = prop->getNextPropertySibling())
            if (opp_strcmp(prop->getName(), "dynamic")==0 && NEDElementUtil::propertyAsBool(prop)==true)
                return;

    // create submodule
    const char *submodname = submod->getName();
    bool usesLike = !opp_isempty(submod->getLikeType());
    ExpressionElement *vectorsizeexpr = findExpression(submod, "vector-size");

    if (!vectorsizeexpr)
    {
        cModuleType *submodtype;
        try {
            std::string submodtypename = getSubmoduleTypeName(modp, submod);
            submodtype = usesLike ?
                findAndCheckModuleTypeLike(submodtypename.c_str(), submod->getLikeType(), modp, submodname) :
                findAndCheckModuleType(submodtypename.c_str(), modp, submodname);
        }
        catch (std::exception& e) {
            updateOrRethrowException(e, submod); throw;
        }

        cModule *submodp = submodtype->create(submodname, modp);
        ModulePtrVector& v = submodMap[submodname];
        v.push_back(submodp);

        cContextSwitcher __ctx(submodp); // params need to be evaluated in the module's context
        submodp->finalizeParameters(); // also sets up gate sizes declared inside the type
        setupSubmoduleGateVectors(submodp, submod);
    }
    else
    {
        // note: we don't try to resolve moduleType if vector size is zero
        int vectorsize = (int) evaluateAsLong(vectorsizeexpr, modp, false);
        ModulePtrVector& v = submodMap[submodname];
        cModuleType *submodtype = NULL;
        for (int i=0; i<vectorsize; i++) {
            if (!submodtype || usesLike) {
                try {
                    std::string submodtypename = getSubmoduleTypeName(modp, submod, i);
                    submodtype = usesLike ?
                        findAndCheckModuleTypeLike(submodtypename.c_str(), submod->getLikeType(), modp, submodname) :
                        findAndCheckModuleType(submodtypename.c_str(), modp, submodname);
                }
                catch (std::exception& e) {
                    updateOrRethrowException(e, submod); throw;
                }
            }
            cModule *submodp = submodtype->create(submodname, modp, vectorsize, i);
            v.push_back(submodp);

            cContextSwitcher __ctx(submodp); // params need to be evaluated in the module's context
            submodp->finalizeParameters(); // also sets up gate sizes declared inside the type
            setupSubmoduleGateVectors(submodp, submod);
        }
    }

    // Note: buildInside() will be called when connections have been built out
    // on this level too.
}

void cNEDNetworkBuilder::assignSubcomponentParams(cComponent *subcomponent, NEDElement *subcomponentNode)
{
    ParametersElement *paramsNode = (ParametersElement *) subcomponentNode->getFirstChildWithTag(NED_PARAMETERS);
    if (paramsNode)
        doParams(subcomponent, paramsNode, true);
}

void cNEDNetworkBuilder::setupSubmoduleGateVectors(cModule *submodule, NEDElement *submoduleNode)
{
    GatesElement *gatesNode = (GatesElement *) submoduleNode->getFirstChildWithTag(NED_GATES);
    if (gatesNode)
        doGateSizes(submodule, gatesNode, true);
}

void cNEDNetworkBuilder::addConnectionOrConnectionGroup(cModule *modp, NEDElement *connOrConnGroup)
{
    // this is tricky: elements representing "for" and "if" in NED are children
    // of the ConnectionElement or ConnectionGroupElement. So, first we have to go through
    // and execute the LoopElement and ConditionElement children recursively to get
    // nested loops etc, then after (inside) the last one create the connection(s)
    // themselves, which is (are) then parent of the LoopNode/ConditionNode.
    NEDSupport::LoopVar::reset();
    doConnOrConnGroupBody(modp, connOrConnGroup, connOrConnGroup->getFirstChild());
}

void cNEDNetworkBuilder::doConnOrConnGroupBody(cModule *modp, NEDElement *connOrConnGroup, NEDElement *loopOrCondition)
{
    // find first "for" or "if" at loopOrCondition (or among its next siblings)
    while (loopOrCondition && loopOrCondition->getTagCode()!=NED_LOOP && loopOrCondition->getTagCode()!=NED_CONDITION)
        loopOrCondition = loopOrCondition->getNextSibling();

    // if there's a "for" or "if", do that, otherwise create the connection(s) themselves
    if (loopOrCondition)
        doLoopOrCondition(modp, loopOrCondition);
    else
        doAddConnOrConnGroup(modp, connOrConnGroup);
}


void cNEDNetworkBuilder::doLoopOrCondition(cModule *modp, NEDElement *loopOrCondition)
{
    if (loopOrCondition->getTagCode()==NED_CONDITION)
    {
        // check condition
        ConditionElement *condition = (ConditionElement *)loopOrCondition;
        ExpressionElement *condexpr = findExpression(condition, "condition");
        if (condexpr && evaluateAsBool(condexpr, modp, false)==true)
        {
            // do the body of the "if": either further "for"'s and "if"'s, or
            // the connection(group) itself that we are children of.
            doConnOrConnGroupBody(modp, loopOrCondition->getParent(), loopOrCondition->getNextSibling());
        }
    }
    else if (loopOrCondition->getTagCode()==NED_LOOP)
    {
        LoopElement *loop = (LoopElement *)loopOrCondition;
        long start = evaluateAsLong(findExpression(loop, "from-value"), modp, false);
        long end = evaluateAsLong(findExpression(loop, "to-value"), modp, false);

        // do loop
        long& i = NEDSupport::LoopVar::pushVar(loop->getParamName());
        for (i=start; i<=end; i++)
        {
            // do the body of the "if": either further "for"'s and "if"'s, or
            // the connection(group) itself that we are children of.
            doConnOrConnGroupBody(modp, loopOrCondition->getParent(), loopOrCondition->getNextSibling());
        }
        NEDSupport::LoopVar::popVar();
    }
    else
    {
        ASSERT(false);
    }
}

void cNEDNetworkBuilder::doAddConnOrConnGroup(cModule *modp, NEDElement *connOrConnGroup)
{
    if (connOrConnGroup->getTagCode()==NED_CONNECTION)
    {
        doAddConnection(modp, (ConnectionElement *)connOrConnGroup);
    }
    else if (connOrConnGroup->getTagCode()==NED_CONNECTION_GROUP)
    {
        ConnectionGroupElement *conngroup = (ConnectionGroupElement *)connOrConnGroup;
        for (ConnectionElement *conn=conngroup->getFirstConnectionChild(); conn; conn=conn->getNextConnectionSibling())
        {
            doConnOrConnGroupBody(modp, conn, conn->getFirstChild());
        }
    }
    else
    {
        ASSERT(false);
    }
}

void cNEDNetworkBuilder::doAddConnection(cModule *modp, ConnectionElement *conn)
{
//FIXME spurious error message comes when trying to connect INOUT gate with "-->"
    try
    {
        if (conn->getArrowDirection()!=NED_ARROWDIR_BIDIR)
        {
            // find gates and create connection
            cGate *srcg = resolveGate(modp, conn->getSrcModule(), findExpression(conn, "src-module-index"),
                                            conn->getSrcGate(), findExpression(conn, "src-gate-index"),
                                            conn->getSrcGateSubg(), conn->getSrcGatePlusplus());
            cGate *destg = resolveGate(modp, conn->getDestModule(), findExpression(conn, "dest-module-index"),
                                             conn->getDestGate(), findExpression(conn, "dest-gate-index"),
                                             conn->getDestGateSubg(), conn->getDestGatePlusplus());

            //printf("creating connection: %s --> %s\n", srcg->getFullPath().c_str(), destg->getFullPath().c_str());

            // check directions
            cGate *errg = NULL;
            if (srcg->getOwnerModule()==modp ? srcg->getType()!=cGate::INPUT : srcg->getType()!=cGate::OUTPUT)
                errg = srcg;
            if (destg->getOwnerModule()==modp ? destg->getType()!=cGate::OUTPUT : destg->getType()!=cGate::INPUT)
                errg = destg;
            if (errg)
                throw cRuntimeError(modp, "Gate %s is being connected in the wrong direction",
                                    errg->getFullPath().c_str());

            doConnectGates(modp, srcg, destg, conn);
        }
        else
        {
            // find gates and create connection in both ways
            if (conn->getSrcGateSubg()!=NED_SUBGATE_NONE || conn->getDestGateSubg()!=NED_SUBGATE_NONE)
                throw cRuntimeError(modp, "gate$i or gate$o used with bidirectional connections");

            // now: 1 is input, 2 is output, except for parent module gates where it is the other way round
            // (because we connect xx.out --> yy.in, but xx.out --> out!)
            cGate *srcg1, *srcg2, *destg1, *destg2;
            resolveInoutGate(modp, conn->getSrcModule(), findExpression(conn, "src-module-index"),
                             conn->getSrcGate(), findExpression(conn, "src-gate-index"),
                             conn->getSrcGatePlusplus(),
                             srcg1, srcg2);
            resolveInoutGate(modp, conn->getDestModule(), findExpression(conn, "dest-module-index"),
                             conn->getDestGate(), findExpression(conn, "dest-gate-index"),
                             conn->getDestGatePlusplus(),
                             destg1, destg2);

            //printf("Creating bidir conn: %s --> %s\n", srcg2->getFullPath().c_str(), destg1->getFullPath().c_str());
            //printf("                and: %s <-- %s\n", srcg1->getFullPath().c_str(), destg2->getFullPath().c_str());

            doConnectGates(modp, srcg2, destg1, conn);
            doConnectGates(modp, destg2, srcg1, conn);
        }
    }
    catch (std::exception& e) {
        updateOrRethrowException(e, conn); throw;
    }
}

void cNEDNetworkBuilder::doConnectGates(cModule *modp, cGate *srcg, cGate *destg, ConnectionElement *conn)
{
    // connect
    ChannelSpecElement *channelspec = conn->getFirstChannelSpecChild();
    if (!channelspec)
    {
        srcg->connectTo(destg);
    }
    else
    {
        cChannel *channel = createChannel(channelspec, modp, srcg);
        channel->setConnectionId(conn->getId()); // so that properties will be found
        srcg->connectTo(destg, channel);
        assignSubcomponentParams(channel, channelspec);
        channel->finalizeParameters();
    }
}

cGate *cNEDNetworkBuilder::resolveGate(cModule *parentmodp,
                                       const char *modname, ExpressionElement *modindexp,
                                       const char *gatename, ExpressionElement *gateindexp,
                                       int subg, bool isplusplus)
{
    //TRACE("resolveGate(mod=%s, %s.%s, subg=%d, plusplus=%d)", parentmodp->getFullPath().c_str(), modname, gatename, subg, isplusplus);

    if (isplusplus && gateindexp)
        throw cRuntimeError(parentmodp, "Both `++' and gate index expression used in a connection");

    cModule *modp = resolveModuleForConnection(parentmodp, modname, modindexp);

    // add "$i" or "$o" suffix to gate name if needed
    std::string tmp;
    const char *gatename2 = gatename;
    if (subg!=NED_SUBGATE_NONE)
    {
        const char *suffix = subg==NED_SUBGATE_I ? "$i" : "$o";
        tmp = gatename;
        tmp += suffix;
        gatename2 = tmp.c_str();
    }

    // look up gate
    cGate *gatep = NULL;
    if (!gateindexp && !isplusplus)
    {
        gatep = modp->gate(gatename2);
    }
    else if (isplusplus)
    {
        if (modp == parentmodp)
        {
            gatep = modp->getOrCreateFirstUnconnectedGate(gatename2, 0, true, false); // inside, don't expand
            if (!gatep)
                throw cRuntimeError(modp, "%s[] gates are all connected, no gate left for `++' operator", gatename);
        }
        else
        {
            gatep = modp->getOrCreateFirstUnconnectedGate(gatename2, 0, false, true); // outside, expand
            ASSERT(gatep!=NULL);
        }
    }
    else // (gateindexp)
    {
        int gateindex = (int) evaluateAsLong(gateindexp, parentmodp, false);
        gatep = modp->gate(gatename2, gateindex);
    }
    return gatep;
}

void cNEDNetworkBuilder::resolveInoutGate(cModule *parentmodp,
                                          const char *modname, ExpressionElement *modindexp,
                                          const char *gatename, ExpressionElement *gateindexp,
                                          bool isplusplus,
                                          cGate *&gate1, cGate *&gate2)
{
    if (isplusplus && gateindexp)
        throw cRuntimeError(parentmodp, "Both `++' and gate index expression used in a connection");

    cModule *modp = resolveModuleForConnection(parentmodp, modname, modindexp);

    gate1 = gate2 = NULL;
    if (!gateindexp && !isplusplus)
    {
        // optimization possibility: add gatePair() method to cModule to spare one lookup
        gate1 = modp->gateHalf(gatename, cGate::INPUT);
        gate2 = modp->gateHalf(gatename, cGate::OUTPUT);
    }
    else if (isplusplus)
    {
        if (modp == parentmodp)
        {
            modp->getOrCreateFirstUnconnectedGatePair(gatename, true, false, gate1, gate2); // inside, don't expand
            if (!gate1 || !gate2)
                throw cRuntimeError(parentmodp, "%s[] gates are all connected, no gate left for `++' operator", gatename);
        }
        else
        {
            modp->getOrCreateFirstUnconnectedGatePair(gatename, false, true, gate1, gate2); // outside, expand
            ASSERT(gate1 && gate2);
        }
    }
    else // (gateindexp)
    {
        // optimization possiblity: add gatePair() method to cModule to spare one lookup
        int gateindex = (int) evaluateAsLong(gateindexp, parentmodp, false);
        gate1 = modp->gateHalf(gatename, cGate::INPUT, gateindex);
        gate2 = modp->gateHalf(gatename, cGate::OUTPUT, gateindex);
    }

    if (modp==parentmodp)
    {
        std::swap(gate1, gate2);
    }
}

cModule *cNEDNetworkBuilder::resolveModuleForConnection(cModule *parentmodp, const char *modname, ExpressionElement *modindexp)
{
    if (opp_isempty(modname))
    {
        return parentmodp;
    }
    else
    {
        int modindex = !modindexp ? 0 : (int) evaluateAsLong(modindexp, parentmodp, false);
        cModule *modp = _submodule(parentmodp, modname,modindex);
        if (!modp)
        {
            if (!modindexp)
                throw cRuntimeError(modp, "No submodule `%s' to be connected", modname);
            else
                throw cRuntimeError(modp, "No submodule `%s[%d]' to be connected", modname, modindex);
        }
        return modp;
    }
}

std::string cNEDNetworkBuilder::getChannelTypeName(cModule *parentmodp, cGate *srcgate, ChannelSpecElement *channelspec, const char *channelname)
{
    std::string channeltypename;
    if (opp_isempty(channelspec->getLikeType()))
    {
        if (!opp_isempty(channelspec->getType())) {
            channeltypename = channelspec->getType();
        }
        else {
            bool hasDelayChannelParams = false, hasOtherParams = false;
            ParametersElement *channelparams = channelspec->getFirstParametersChild();
            if (channelparams) {
                for (ParamElement *param=channelparams->getFirstParamChild(); param; param=param->getNextParamSibling())
                    if (strcmp(param->getName(),"delay")==0 || strcmp(param->getName(),"disabled")==0)
                        hasDelayChannelParams = true;
                    else
                        hasOtherParams = true;
            }

            // choose one of the three built-in channel types, based on the channel's parameters
            channeltypename = hasOtherParams ? "ned.DatarateChannel" : hasDelayChannelParams ? "ned.DelayChannel" : "ned.IdealChannel";
        }
    }
    else
    {
        // type may be given either in ExpressionElement child or "like-param" attribute
        if (!opp_isempty(channelspec->getLikeParam())) {
            channeltypename = parentmodp->par(channelspec->getLikeParam()).stringValue();
        }
        else {
            ExpressionElement *likeParamExpr = findExpression(channelspec, "like-param");
            if (likeParamExpr)
                channeltypename = evaluateAsString(likeParamExpr, parentmodp, false);
            else {
                std::string key = srcgate->getFullPath() + "." + channelname;
                channeltypename = ev.getConfig()->getAsString(key.c_str(), CFGID_TYPE_NAME);
                if (channeltypename.empty())
                    throw cRuntimeError(parentmodp, "Unable to determine type name for channel: missing config entry %s.%s", key.c_str(), CFGID_TYPE_NAME->getName());
            }
        }
    }

    return channeltypename;
}

cChannel *cNEDNetworkBuilder::createChannel(ChannelSpecElement *channelspec, cModule *parentmodp, cGate *srcgate)
{
    // resolve channel type
    const char *channelname = "channel";
    cChannelType *channeltype;
    try {
        std::string channeltypename = getChannelTypeName(parentmodp, srcgate, channelspec, channelname);
        bool usesLike = !opp_isempty(channelspec->getLikeType());
        channeltype = usesLike ?
            findAndCheckChannelTypeLike(channeltypename.c_str(), channelspec->getLikeType(), parentmodp) :
            findAndCheckChannelType(channeltypename.c_str(), parentmodp);
    }
    catch (std::exception& e) {
        updateOrRethrowException(e, channelspec); throw;
    }

    // create channel object
    cChannel *channelp = channeltype->create(channelname);
    return channelp;
}

cChannelType *cNEDNetworkBuilder::findAndCheckChannelType(const char *channeltypename, cModule *modp)
{
    //FIXME cache the result to speed up further lookups
    NEDLookupContext context(currentDecl->getTree(), currentDecl->getFullName());
    std::string qname = resolveComponentType(context, channeltypename);
    if (qname.empty())
        throw cRuntimeError(modp, "Cannot resolve channel type `%s' (not in the loaded NED files?)", channeltypename);

    cComponentType *componenttype = cComponentType::find(qname.c_str());
    if (!dynamic_cast<cChannelType *>(componenttype))
        throw cRuntimeError(modp, "`%s' is not a channel type", qname.c_str());
    return (cChannelType *)componenttype;
}

cChannelType *cNEDNetworkBuilder::findAndCheckChannelTypeLike(const char *channeltypename, const char *likeType, cModule *modp)
{
    //FIXME cache the result to speed up further lookups

    // resolve the interface
    NEDLookupContext context(currentDecl->getTree(), currentDecl->getFullName());
    std::string interfaceqname = cNEDLoader::getInstance()->resolveNedType(context, likeType);
    cNEDDeclaration *interfacedecl = interfaceqname.empty() ? NULL : (cNEDDeclaration *)cNEDLoader::getInstance()->lookup(interfaceqname.c_str());
    if (!interfacedecl)
        throw cRuntimeError(modp, "Cannot resolve channel interface `%s'", likeType);
    if (interfacedecl->getTree()->getTagCode()!=NED_CHANNEL_INTERFACE)
        throw cRuntimeError(modp, "`%s' is not a channel interface", interfaceqname.c_str());

    // search for channel type that implements the interface
    std::vector<std::string> candidates = findTypeWithInterface(channeltypename, interfaceqname.c_str());
    if (candidates.empty())
        throw cRuntimeError(modp, "No channel type named `%s' found that implements channel interface %s (not in the loaded NED files?)",
                            channeltypename, interfaceqname.c_str());
    if (candidates.size() > 1)
        throw cRuntimeError(modp, "More than one channel types named `%s' found that implement channel interface %s (use fully qualified name to disambiguate)",
                            channeltypename, interfaceqname.c_str());

    cComponentType *componenttype = cComponentType::find(candidates[0].c_str());
    if (!dynamic_cast<cChannelType *>(componenttype))
        throw cRuntimeError(modp, "`%s' is not a channel type", candidates[0].c_str());
    return (cChannelType *)componenttype;
}

ExpressionElement *cNEDNetworkBuilder::findExpression(NEDElement *node, const char *exprname)
{
    // find expression with given name in node
    if (!node)
        return NULL;
    for (NEDElement *child=node->getFirstChildWithTag(NED_EXPRESSION); child; child = child->getNextSiblingWithTag(NED_EXPRESSION))
    {
        ExpressionElement *expr = (ExpressionElement *)child;
        if (!strcmp(expr->getTarget(),exprname))
            return expr;
    }
    return NULL;
}

cParImpl *cNEDNetworkBuilder::getOrCreateExpression(ExpressionElement *exprNode, cPar::Type type, const char *unit, bool inSubcomponentScope)
{
    cParImpl *p = currentDecl->getSharedParImplFor(exprNode);
    if (!p)
    {
        cDynamicExpression *e = cExpressionBuilder().process(exprNode, inSubcomponentScope);
        p = cParImpl::createWithType(type);
        cExpressionBuilder::setExpression(p, e);
        p->setUnit(unit);

        currentDecl->putSharedParImplFor(exprNode, p);
    }
    return p;
}

long cNEDNetworkBuilder::evaluateAsLong(ExpressionElement *exprNode, cComponent *context, bool inSubcomponentScope)
{
    try {
        cParImpl *p = getOrCreateExpression(exprNode, cPar::LONG, NULL, inSubcomponentScope);
        return p->longValue(context);
    }
    catch (std::exception& e) {
        updateOrRethrowException(e, exprNode); throw;
    }
}

bool cNEDNetworkBuilder::evaluateAsBool(ExpressionElement *exprNode, cComponent *context, bool inSubcomponentScope)
{
    try {
        cParImpl *p = getOrCreateExpression(exprNode, cPar::BOOL, NULL, inSubcomponentScope);
        return p->boolValue(context);
    }
    catch (std::exception& e) {
        updateOrRethrowException(e, exprNode); throw;
    }
}

std::string cNEDNetworkBuilder::evaluateAsString(ExpressionElement *exprNode, cComponent *context, bool inSubcomponentScope)
{
    try {
        cParImpl *p = getOrCreateExpression(exprNode, cPar::STRING, NULL, inSubcomponentScope);
        return p->stdstringValue(context);
    }
    catch (std::exception& e) {
        updateOrRethrowException(e, exprNode); throw;
    }
}

