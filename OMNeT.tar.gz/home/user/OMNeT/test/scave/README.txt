To test this component run the perl scripts in this directory
without any parameters. To see the result check standard output
and for more details look in the created result directory.
