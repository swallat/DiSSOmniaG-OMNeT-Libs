system("perl generate.pl");
system("perl filter.pl");
system("perl eventlogindextest.pl");
system("perl eventlogtest.pl");
system("perl eventlogtooltest.pl");
