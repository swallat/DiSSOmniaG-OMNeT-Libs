#ifndef TESTUTIL_H
#define TESTUTIL_H

#include <omnetpp.h>

void printEnum(const char *enumname);

#endif
